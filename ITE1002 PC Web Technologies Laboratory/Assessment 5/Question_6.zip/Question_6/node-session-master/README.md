node-session
============
Handle Session in express JS 4.0 above. Code is latest and updated.

Tutorial link : http://codeforgeek.com/2014/09/manage-session-using-node-js-express-4/
